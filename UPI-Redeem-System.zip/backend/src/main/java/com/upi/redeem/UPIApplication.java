package com.upi.redeem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UPIApplication {
    public static void main(String[] args) {
        SpringApplication.run(UPIApplication.class, args);
    }
}
